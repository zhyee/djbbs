<?php
if (!defined('InternalAccess')) exit('error: 403 Access Denied');
?>
<p><?php echo $Error;?></p>